import numpy as np
import matplotlib.pyplot as plt
plt.rcParams.update({
    "text.usetex": True,
    "font.family": "sans-serif",
    "font.sans-serif": ["Helvetica"]})
import matplotlib.mlab as mlab
import matplotlib.gridspec as gridspec

import json
import munch
import os
import logging

import equations as eqn

from absl import app
from absl import flags
from absl import logging as absl_logging


flags.DEFINE_string('config_path', 'configs/PA_configs.json',
                    """The path to load json file.""")
flags.DEFINE_string('config_path_', 'configs/PA_configs_.json',
                    """The path to load json file.""")

FLAGS = flags.FLAGS



def main(argv):
    del argv
    with open(FLAGS.config_path) as json_data_file:
        config = json.load(json_data_file)
    config = munch.munchify(config)
    with open(FLAGS.config_path_) as json_data_file_:
        config_ = json.load(json_data_file_)
    config_ = munch.munchify(config_)
#         bsde = getattr(eqn, config.eqn_config.eqn_name)(config.eqn_config)
    # print(config.eqn_config.param[3])
    ode_Ff = getattr(eqn,config.bvp_config.eqn_name)(config)
    ode_Ff_ = getattr(eqn,config.bvp_config.eqn_name)(config_)
    print('[mu, gamma, r ,lmb ,sgm, rho]: ',ode_Ff.param)
    ode_Ff.solver()
    print('[mu, gamma, r ,lmb ,sgm, rho]: ',ode_Ff_.param)
    ode_Ff_.solver()
    # ode_FfS.empirical_tau(0.35)
    print(ode_Ff.message)
    print(ode_Ff_.message)
    fig = plt.figure(figsize=(12, 12),constrained_layout=True)
    gs = gridspec.GridSpec(3, 1, figure=fig)
    f_m = fig.add_subplot(gs[0, 0])
    df_m = fig.add_subplot(gs[1, 0])
    ddf_m = fig.add_subplot(gs[2, 0])
    S = ode_Ff.f ; labS = '$\sigma = [$'\
+ ', '.join([str(round(num,2)) for num in ode_Ff.param[4]])\
+ '$]$\n' + r'$\rho = [$' + ', '.join([str(round(num,2)) for num in ode_Ff.param[5]])\
+ '$]$\n ' + '$m_p = $' +  str(round(ode_Ff.m_p,2))
    S_ = ode_Ff_.f ; labS_ = '$\sigma = [$'\
+ ', '.join([str(round(num,2)) for num in ode_Ff_.param[4]])\
+ '$]$' + '\n ' + r'$\rho = [$' + ', '.join([str(0.5 + round(num,2)) for num in ode_Ff_.param[5]])\
+ '$]$\n ' + '$m_p = $' +  str(round(ode_Ff_.m_p,2))
    df_m.plot(ode_Ff.x, ode_Ff.df, label = labS, color = 'b')
    df_m.plot(ode_Ff_.x, ode_Ff_.df, label = labS_, color = 'r')
    ddf_m.plot(ode_Ff.x, ode_Ff.ddf, 'b')
    ddf_m.plot(ode_Ff_.x, ode_Ff_.ddf, 'r')
    f_m.plot(ode_Ff.x, ode_Ff.f,  'b')
    f_m.plot(ode_Ff_.x, ode_Ff_.f, 'r')
    f_m.plot(ode_Ff.x, ode_Ff.fline, 'b')
    f_m.plot(ode_Ff_.x, ode_Ff_.fline, 'r')
    f_m.set_title('$f(m)$')
    df_m.set_title('$f^{\prime}(m)$')
    ddf_m.set_title('$f^{\prime\prime}(m)$')
    df_m.legend(loc='upper center', shadow=True,ncol=1, bbox_to_anchor=(0.7, 0.9))
    ddf_m.plot(ode_Ff.x,np.ones(len(ode_Ff.ddf))*ode_Ff.swtch[0], 'k:')
    ddf_m.plot(ode_Ff.x,np.ones(len(ode_Ff.ddf))*ode_Ff.swtch[1], 'k:')
    plt.show(block=False)
    input()
    plt.close()



if __name__ == '__main__':
    app.run(main)
