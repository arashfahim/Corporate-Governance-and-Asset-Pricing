import numpy as np
import math
from scipy import integrate
from scipy.integrate import solve_bvp
import datetime as dt
def findMin(X):
    x=np.amin(X)
    for index, i in enumerate(X):
        if i == x:
            return index, i


class Equation(object):
    """Base class for a boundary value problem"""

    def __init__(self,config):
        self.config = config
        self.range = config.eqn_config.range
        """param=[mu, gamma, r ,lmb ,sgm, rho]"""
        self.param = config.eqn_config.param
        self.y_init = 0
        self.Gamma = self.Gamma_order()
        """Parameters for the solver"""
        self.N = self.config.ode_config.N
        self.dx = self.range/self.N
        self.x = np.linspace(0,self.range,self.N)
        self.y = np.empty(self.N)
        self.line = [(self.param[0] - self.param[1] * x)/self.param[2] for x in self.x]
        self.dy = np.empty(self.N)
        self.ddy = np.empty(self.N)
        self.Upper_dy_lim = config.ode_config.Upper_dy_lim
        self.Lower_dy_lim = config.ode_config.Lower_dy_lim
        self.it = config.ode_config.num_iterations
        self.eps = config.ode_config.eps
        self.N = config.ode_config.N
        self.df0 = config.ode_config.df0
        self.y = np.empty(self.N)
        self.dy = np.empty(self.N)
        self.ddy = np.empty(self.N)
        self.num_paths =  config.bvp_config.num_paths
        self.upper_limit = config.bvp_config.upper_limit
        self.num_samples =  self.num_paths*self.upper_limit




    def nonlinear(self,X,param):
        """Nonlinearity H: ddy = H(dy,y,x)"""
        raise NotImplementedError

    def optimal_sigma(self,X,param):
        """Nonlinearity H: ddy = H(dy,y,x)"""
        raise NotImplementedError

    def Gamma_order(self):
        """Filtering sigma and rho for """
        raise NotImplementedError

    def solver(self):
        """Solver for the equation"""
        raise NotImplementedError

    def findD(self,X):
        x=np.amin(X)
        for index, i in enumerate(X):
            if i == x:
                return index, i


class eqn_Ff(Equation):
    """The equation for principal as a function of the agents value"""
    def __init__(self,config):
        super().__init__(config)



    def Gamma_order(self):
        sgm_ = self.param[4]
        rho_ = self.param[5]
        Gamma = []
        self.swtch = []
        _sgm_ = [sgm_[0]]
        _rho_ = [rho_[0]]
        for i in range(0,len(sgm_)):
            for j in range(1,len(sgm_)):
                if i < j:
                    gamma = 2*(rho_[i]-rho_[j])/(sgm_[i]*sgm_[i]-sgm_[j]*sgm_[j])
                    val = -gamma*(sgm_[j]*sgm_[j])/2 + rho_[j]
                    val_tmp = val
                    for k in range(0,len(sgm_)):
                        if k != i and k != j:
                            val_tmp =  np.minimum(val_tmp,-gamma*(sgm_[k]*sgm_[k])/2 + rho_[k])
                    if val_tmp == val:
                        gamma_ = [gamma , i , j]
                        Gamma.append(gamma_)
        Gamma = sorted(Gamma, reverse =True)
        # print('sgm = ',sgm_[0], '      AND rho = ', rho_[0])
        print('Switching values and active regimes:\n ')
        for index, i in enumerate(Gamma):
                _sgm_.append(sgm_[Gamma[index][2]])
                _rho_.append(rho_[Gamma[index][2]])
                self.swtch.append(Gamma[index][0])#/(self.param[3]*self.param[3]))
                print(Gamma[index][1], ' to ', Gamma[index][2], ' at Gamma_',index+1,' = ', round(Gamma[index][0],3),' \n')
        # _sgm_.reverse()
        self.param[4] = _sgm_
        self.param[5] = _rho_


    def nonlinear(self,X):
        """Nonlinearity H: ddF = H(dF,F,w)"""
        lmb = self.param[3]
        sgm = self.param[4]
        rho = self.param[5]
        if len(sgm) != len(rho):
            raise print("sigma and rho must me the same length.")
        H_inv = -2*(X-rho[0])/(sgm[0]*sgm[0]*lmb*lmb)
        for i in range(1,len(sgm)):
            H_inv = np.min((H_inv, -2*(X-rho[i])/(sgm[i]*sgm[i]*lmb*lmb)), axis=0)
        return H_inv


    def bvp_solve(self):
        def RHS(X, t, param):
            H_ = [X[1], self.nonlinear(param[0] - param[2] * X[0] + param[1]*np.multiply(t,X[1]))]
            return H_
        df0 = self.df0
        cond = [0, df0]
        Udf_tmp=self.Upper_dy_lim
        Ldf_tmp=self.Lower_dy_lim
        param = self.param
        # self.Gamma_order()
        a_t = self.x
        b_t = self.line
        asol = integrate.odeint(RHS, cond, a_t, args=(param,))
        F=asol[:,0]
        dF=asol[:,1]
        """[mu, gamma, r ,lmb ,sgm, rho]:"""
        ddF = self.nonlinear(param[0] - param[2] * F + param[1]*np.multiply(a_t,dF))
        __w__=findMin(dF)
        if __w__[1]<-1:
            Ldf_tmp=df0
            df0 += (Udf_tmp-df0)/2
        else:
            Udf_tmp=df0
            df0 -= df0/2
        self.df0 = df0
        self.Upper_dy_lim = Udf_tmp
        self.Lower_dy_lim = Ldf_tmp
        self.y = F
        self.dy = dF
        self.ddy = ddF
        self.__ddw__ = findMin(np.absolute(self.ddy))
        self.__w__ = findMin(np.absolute(self.y-self.line))
        self.__dw__ = findMin(self.dy)


    def solver(self):
        var = 1
        k=0
        while k<self.it and var>self.eps:
            self.bvp_solve()
            k += 1
            temp_k = k/50
            var=np.absolute(self.dy[self.__w__[0]]+1)*np.absolute(self.dy[self.__w__[0]]+1)\
+np.absolute(self.ddy[self.__w__[0]])*np.absolute(self.ddy[self.__w__[0]])\
+np.absolute(self.y[self.__w__[0]]-self.line[self.__w__[0]])*\
np.absolute(self.y[self.__w__[0]]-self.line[self.__w__[0]])
            if (temp_k.is_integer()):
                print('var = ',round(var,5),'       Iteration = ',k)
        print('var = ',round(var,5),'       Iteration = ',k)




        __x_s__ = findMin(np.absolute(self.dy))
        self.x_s = self.x[__x_s__[0]]
        self.x_p = self.x[self.__w__[0]+1]
        self.m = self.x/self.param[3]

        self.y = np.where(self.ddy <= 0, self.y, self.y[self.__w__[0]]-(self.x - self.x_p))
        self.dy = np.where(self.ddy <= 0, self.dy, -1)
        self.ddy = np.where(self.ddy <= 0, self.ddy, 0)

        self.m_s = self.x_s/self.param[3]
        self.m_p = self.x_p/self.param[3]
        self.f = self.y
        self.df = self.dy*self.param[3]
        self.ddf = self.ddy*self.param[3]*self.param[3]
        self.fline = [(self.param[0] - self.param[1] * self.param[3] * x)/self.param[2] for x in self.m]
        self.sol= {'domain':self.x, 'solution':self.y,'1st_deriv':self.dy,'2nd_deriv':self.dy,'3rd_deriv':self.ddy,'pay_point':self.x_p, 'negot_point':self.x_s}
        self.message = f'''\nThis solves the value function as a function of w, the agent's utility.\n\n'''\
'''If the three numbers below, approximations of payment boundary by three methods,\
are almost equal, the scheme is working. \
\nOtherwise, reset df0 in the json file and run the code again.\n\
Calculation of payment boundary by three methods: \n\
Minimum of abs(F-(mu-gamma*x)/r,  Minimum of abs(dF+1), and Minimum of abs(ddF) are, respectively, at\n'''\
+str(round(self.x[self.__w__[0]],5))+', '\
+str(round(self.x[self.__dw__[0]],5))+', and '\
+str(round(self.x[self.__ddw__[0]],5))+'. '\
+'''\nThe value of dF(0) is '''+ str(round(self.dy[0],5))\
+'''. \nIf the principal has the bargaining power, the minimum utility of the agent is '''\
+str(round(self.x_s,5))+'.'\
+'''\nThe initial capital to start implemeting the contract is '''\
+str(round(self.x_s/self.param[3],5))+'. '+''' \nThe divident boundary is given by '''\
+str(round(self.m_p,5))+'. '



        ####################



class eqn_FfS(eqn_Ff):
    """The equation for principal as a function of the agents value"""
    def __init__(self,config):
        super().__init__(config)

    def optimal_sigma(self,t):
        sgm_ = self.param[4]
        temp_swtch = [0]
        temp_swtch.extend(self.swtch)
        temp_swtch.append(self.swtch[-1]+np.min(self.ddf)-1)
        y = np.ones(len(t))
        for indexm, i in enumerate(t):
            i__ = self.findD(np.abs(t[indexm]-self.m))
            y[indexm] = self.ddf[i__[0]]
        for index, g in enumerate(temp_swtch[0:-1]):
            y = np.where((y <= g) & (y > temp_swtch[index+1]), sgm_[index], y)
        return y





    def bvp_S(self):
        self.solver()
        def eqn_form(t, X):
            dis_cnt_coeff = 2/(self.optimal_sigma(t)*self.optimal_sigma(t))
            H_ = np.vstack((X[1], dis_cnt_coeff*(self.param[2]*X[0] -self.param[1]*t * X[1])))
            return H_
        def bc(ya, yb):
            return np.array([ya[0], yb[1]-1])
        self.mS = self.m[0:(self.__w__[0]+1)]
        init_y  = np.ones((2,len(self.mS)))
        init_y[0] = np.power(self.mS,4/5)
        a = dt.datetime.now()
        sol = solve_bvp(eqn_form, bc, self.mS, init_y)
        b = dt.datetime.now() - a
        print('BVP for S is solved in',b.total_seconds(),'seconds.\n')
        self.S = sol.sol(self.mS)[0]
        self.dS = sol.sol(self.mS)[1]
        dis_cnt_coeff = 2/(self.optimal_sigma(self.mS)*self.optimal_sigma(self.mS))
        self.ddS = (self.param[2] * self.S - self.param[1] * self.mS * self.dS)\
*dis_cnt_coeff


    def sample(self,x):
        Dlt_B = np.random.normal(0, self.dx, size=(self.num_samples))
        dt = self.dx*self.dx
        i = 0
        path = [x]
        tau = 0
        while ((i<self.num_samples) & (path[-1]>0)):
            tmp = np.amin([0.7, path[-1] + Dlt_B[i]])
            path.append(tmp)
            tau = tau + dt
            i = i + 1
            if (path[-1]< 0):
                path[-1] = 0
        return np.array([tau,path])

    def empirical_tau(self,x):
        T = 0
        k = 0
        for i in range(0,self.num_paths):
            tau, path = self.sample(x)
            if path[-1] == 0:
                k = k + 1
                T = T + tau
        print('''Percent of path reached zero = ''',\
k/self.num_samples,'\n','Expected tau = ',T/self.num_paths)












#END OF THE CODE
